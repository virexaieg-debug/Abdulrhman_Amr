export type Language = 'ar' | 'en';

export interface Translations {
  [key: string]: string | Translations;
}

export const translations = {
  ar: {
    // Navigation
    nav: {
      home: 'الرئيسية',
      services: 'الخدمات',
      academic: 'التدريب',
      about: 'عني',
      contact: 'تواصل',
    },
    // Hero Section
    hero: {
      greeting: 'مرحباً، أنا',
      name: 'عبد الرحمن عمرو',
      title: 'أجمع بين الرؤية الإدارية العميقة وأحدث تقنيات العصر لأقود التحول الرقمي',
      subtitle: 'تمكين المؤسسات من التفوق في عصر الذكاء الاصطناعي عبر أدوات ذكية وإدارة حكيمة',
      cta: 'تواصل معي',
    },
    // Services Section
    services: {
      title: 'خدماتي',
      subtitle: 'حلول متكاملة للتحول الرقمي',
      items: {
        ai: {
          title: 'الإدارة بالذكاء الاصطناعي',
          description: 'تطبيق حلول الذكاء الاصطناعي لتحسين العمليات الإدارية وزيادة الكفاءة التشغيلية',
        },
        web: {
          title: 'تصميم وتطوير المواقع',
          description: 'بناء مواقع احترافية وتطبيقات ويب متقدمة بأحدث التقنيات',
        },
        consulting: {
          title: 'استشارات الإدارة العامة',
          description: 'تقديم استشارات استراتيجية لتحسين الأداء المؤسسي وتحقيق الأهداف',
        },
      },
    },
    // Academic Section
    academic: {
      title: 'الجانب الأكاديمي والتدريبي',
      subtitle: 'خبرة تدريبية معتمدة',
      description: 'مدرب معتمد للذكاء الاصطناعي لدى كبرى الشركات الأمريكية، أساعد المؤسسات والأفراد على استيعاب وتطبيق أحدث تقنيات الذكاء الاصطناعي في بيئات العمل المختلفة.',
      stats: {
        companies: 'شركة تم التدريب بها',
        trainees: 'متدرب تم تدريبه',
        sessions: 'جلسة تدريبية',
      },
    },
    // About Section
    about: {
      title: 'من أنا',
      subtitle: 'سد الفجوة بين التكنولوجيا والتطبيق العملي',
      description1: 'أؤمن بأن التكنولوجيا ليست مجرد أدوات، بل هي وسيلة لتحقيق التحول الحقيقي في المؤسسات. مهمتي هي سد الفجوة بين ما هو تقني وما هو عملي، لأجعل التحول الرقمي رحلة ممكنة ومثمرة لكل مؤسسة.',
      description2: 'أجمع بين الفهم العميق للإدارة والمعرفة التقنية المتقدمة، لأقدم حلولاً متكاملة تجمع بين الرؤية الاستراتيجية والتنفيذ العملي.',
      mission: 'المهمة',
      vision: 'الرؤية',
      missionText: 'تمكين المؤسسات من تحقيق التفوق من خلال التحول الرقمي الذكي',
      visionText: 'عالم يتكيف مع التكنولوجيا بذكاء ويسخرها لخدمة الإنسان',
    },
    // Footer
    footer: {
      title: 'تواصل معي',
      subtitle: 'جاهز لمساعدتك في رحلة التحول الرقمي',
      form: {
        name: 'الاسم',
        email: 'البريد الإلكتروني',
        message: 'الرسالة',
        send: 'إرسال',
        success: 'تم إرسال رسالتك بنجاح!',
      },
      social: 'تابعني',
      rights: 'جميع الحقوق محفوظة',
    },
  },
  en: {
    // Navigation
    nav: {
      home: 'Home',
      services: 'Services',
      academic: 'Training',
      about: 'About',
      contact: 'Contact',
    },
    // Hero Section
    hero: {
      greeting: 'Hello, I am',
      name: 'Abdulrhman Amr',
      title: 'Combining deep managerial vision with cutting-edge technology to lead digital transformation',
      subtitle: 'Empowering organizations to excel in the AI era through smart tools and wise management',
      cta: 'Contact Me',
    },
    // Services Section
    services: {
      title: 'My Services',
      subtitle: 'Integrated solutions for digital transformation',
      items: {
        ai: {
          title: 'AI Operations',
          description: 'Implementing AI solutions to improve administrative processes and increase operational efficiency',
        },
        web: {
          title: 'Web Development',
          description: 'Building professional websites and advanced web applications with the latest technologies',
        },
        consulting: {
          title: 'Strategic Consulting',
          description: 'Providing strategic consulting to improve organizational performance and achieve goals',
        },
      },
    },
    // Academic Section
    academic: {
      title: 'Academic & Training',
      subtitle: 'Certified training experience',
      description: 'Certified AI trainer for major American companies, helping organizations and individuals understand and apply the latest AI technologies in various work environments.',
      stats: {
        companies: 'Companies Trained',
        trainees: 'Trainees',
        sessions: 'Training Sessions',
      },
    },
    // About Section
    about: {
      title: 'Who I Am',
      subtitle: 'Bridging the gap between technology and practical application',
      description1: 'I believe that technology is not just tools, but a means to achieve real transformation in organizations. My mission is to bridge the gap between what is technical and what is practical, making digital transformation a possible and fruitful journey for every organization.',
      description2: 'I combine deep management understanding with advanced technical knowledge to provide integrated solutions that combine strategic vision with practical implementation.',
      mission: 'Mission',
      vision: 'Vision',
      missionText: 'Empowering organizations to achieve excellence through smart digital transformation',
      visionText: 'A world that adapts intelligently to technology and harnesses it to serve humanity',
    },
    // Footer
    footer: {
      title: 'Get in Touch',
      subtitle: 'Ready to help you in your digital transformation journey',
      form: {
        name: 'Name',
        email: 'Email',
        message: 'Message',
        send: 'Send',
        success: 'Your message has been sent successfully!',
      },
      social: 'Follow Me',
      rights: 'All rights reserved',
    },
  },
};
