import { useState } from 'react';
import { useLanguage } from '@/hooks/useLanguage';
import { 
  Send, 
  Linkedin, 
  Twitter, 
  Github, 
  Mail, 
  MapPin, 
  Phone,
  ArrowUpRight,
  CheckCircle
} from 'lucide-react';

export default function Footer() {
  const { t, language } = useLanguage();
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({ name: '', email: '', message: '' });
    }, 3000);
  };

  const socialLinks = [
    { icon: Linkedin, href: '#', label: 'LinkedIn' },
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Github, href: '#', label: 'GitHub' },
    { icon: Mail, href: 'mailto:contact@abdulrhman.com', label: 'Email' },
  ];

  const quickLinks = [
    { key: 'nav.home', href: '#hero' },
    { key: 'nav.services', href: '#services' },
    { key: 'nav.academic', href: '#academic' },
    { key: 'nav.about', href: '#about' },
  ];

  return (
    <footer id="contact" className="relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-t from-purple-900/20 to-background" />
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-purple-600/10 rounded-full blur-[150px]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Contact Section */}
        <div className="section-padding">
          <div className="text-center mb-16" data-aos="fade-up">
            <span className="inline-block px-4 py-2 rounded-full glass text-sm text-cyan-400 mb-4">
              {t('footer.subtitle') as string}
            </span>
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              <span className="gradient-text">{t('footer.title') as string}</span>
            </h2>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div data-aos="fade-right">
              <form onSubmit={handleSubmit} className="glass rounded-3xl p-8">
                {isSubmitted ? (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <div className="w-16 h-16 rounded-full bg-green-500/20 flex items-center justify-center mb-4">
                      <CheckCircle className="w-8 h-8 text-green-500" />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">
                      {t('footer.form.success') as string}
                    </h3>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm text-gray-400 mb-2">
                        {t('footer.form.name') as string}
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-purple-500 transition-colors"
                        placeholder={language === 'ar' ? 'أدخل اسمك' : 'Enter your name'}
                      />
                    </div>
                    <div>
                      <label className="block text-sm text-gray-400 mb-2">
                        {t('footer.form.email') as string}
                      </label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-purple-500 transition-colors"
                        placeholder={language === 'ar' ? 'أدخل بريدك الإلكتروني' : 'Enter your email'}
                      />
                    </div>
                    <div>
                      <label className="block text-sm text-gray-400 mb-2">
                        {t('footer.form.message') as string}
                      </label>
                      <textarea
                        required
                        rows={4}
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-purple-500 transition-colors resize-none"
                        placeholder={language === 'ar' ? 'اكتب رسالتك هنا...' : 'Write your message here...'}
                      />
                    </div>
                    <button
                      type="submit"
                      className="w-full btn-primary flex items-center justify-center gap-2"
                    >
                      <span>{t('footer.form.send') as string}</span>
                      <Send className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </form>
            </div>

            {/* Contact Info */}
            <div data-aos="fade-left" className="space-y-8">
              {/* Social Links */}
              <div className="glass rounded-3xl p-8">
                <h3 className="text-lg font-bold text-white mb-6">
                  {t('footer.social') as string}
                </h3>
                <div className="flex gap-4">
                  {socialLinks.map((social, index) => {
                    const Icon = social.icon;
                    return (
                      <a
                        key={index}
                        href={social.href}
                        className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center text-gray-400 hover:text-white hover:bg-purple-500/20 transition-all duration-300 hover:scale-110"
                        aria-label={social.label}
                      >
                        <Icon className="w-5 h-5" />
                      </a>
                    );
                  })}
                </div>
              </div>

              {/* Contact Details */}
              <div className="glass rounded-3xl p-8 space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center">
                    <Mail className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <div className="text-sm text-gray-400">Email</div>
                    <a href="mailto:abdulrhmana278@gmail.com" className="text-white hover:text-purple-400 transition-colors">
                      abdulrhmana278@gmail.com
                    </a>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                    <Phone className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <div className="text-sm text-gray-400">Phone</div>
                    <div className="flex flex-col gap-1">
                      <a href="tel:+201124362572" className="text-white hover:text-cyan-400 transition-colors">
                        01124362572
                      </a>
                      <a href="tel:+201030456378" className="text-white hover:text-cyan-400 transition-colors">
                        01030456378
                      </a>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-pink-500 to-rose-600 flex items-center justify-center">
                    <MapPin className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <div className="text-sm text-gray-400">Location</div>
                    <span className="text-white">{language === 'ar' ? 'مصر' : 'Egypt'}</span>
                  </div>
                </div>
              </div>

              {/* Quick Links */}
              <div className="glass rounded-3xl p-8">
                <h3 className="text-lg font-bold text-white mb-4">
                  {language === 'ar' ? 'روابط سريعة' : 'Quick Links'}
                </h3>
                <div className="flex flex-wrap gap-3">
                  {quickLinks.map((link, index) => (
                    <a
                      key={index}
                      href={link.href}
                      className="flex items-center gap-1 px-4 py-2 rounded-full bg-white/5 text-gray-400 hover:text-white hover:bg-white/10 transition-all text-sm"
                    >
                      {t(link.key) as string}
                      <ArrowUpRight className="w-3 h-3" />
                    </a>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-white/10 py-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-gray-500 text-sm">
              © {new Date().getFullYear()} Abdulrhman Amr. {t('footer.rights') as string}
            </div>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold gradient-text">AA</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
